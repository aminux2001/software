<?php
include('config/db.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['application_id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE application_id = ?");
    $stmt->bind_param("si", $status, $id);
    $stmt->execute();
    header("Location: admin_dashboard.php");
}
?>
