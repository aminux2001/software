<?php
$openai_api_key = '';
