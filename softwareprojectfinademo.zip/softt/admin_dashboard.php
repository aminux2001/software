<?php
session_start();
include('config/db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Handle filtering
$filter = $_GET['company_filter'] ?? '';

// Queries
$users = $conn->query("SELECT * FROM users ORDER BY role");

$jobs_sql = "SELECT jobs.*, users.username AS company_name FROM jobs JOIN users ON jobs.company_id = users.id";
if ($filter) {
    $jobs_sql .= " WHERE users.id = '$filter'";
}
$jobs = $conn->query($jobs_sql);

$applications = $conn->query("SELECT applications.*, jobs.title, u.username AS employee_name FROM applications JOIN jobs ON applications.job_id = jobs.job_id JOIN users u ON applications.employee_id = u.id");

$total_users = $users->num_rows;
$total_jobs = $jobs->num_rows;
$total_applications = $applications->num_rows;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - MoroccoHire</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div class="navbar">MoroccoHire Admin Panel</div>

    <div class="container">

        <h3>📈 Platform Summary</h3>
        <ul>
            <li>Total Users: <?= $total_users ?></li>
            <li>Total Jobs: <?= $total_jobs ?></li>
            <li>Total Applications: <?= $total_applications ?></li>
        </ul>

        <h2>👥 All Users</h2>
        <a href="export_users.php">Export Users</a>
        <table>
            <tr>
                <th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Actions</th>
            </tr>
            <?php while($user = $users->fetch_assoc()): ?>
                <tr>
                    <td><?= $user['id'] ?></td>
                    <td><?= htmlspecialchars($user['username']) ?></td>
                    <td><?= htmlspecialchars($user['email']) ?></td>
                    <td><?= ucfirst($user['role']) ?></td>
                    <td>
                        <a href="edit_user.php?id=<?= $user['id'] ?>">Edit</a> |
                        <a href="delete_user.php?id=<?= $user['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h2>💼 All Job Posts</h2>
        <a href="export_jobs.php">Export Jobs</a>
        <form method="GET" style="margin:10px 0;">
            <label>Filter by Company:</label>
            <select name="company_filter" onchange="this.form.submit()">
                <option value="">All</option>
                <?php
                $companies = $conn->query("SELECT DISTINCT id, username FROM users WHERE role = 'company'");
                while($comp = $companies->fetch_assoc()):
                ?>
                    <option value="<?= $comp['id'] ?>" <?= $filter == $comp['id'] ? 'selected' : '' ?>>
                        <?= $comp['username'] ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
        <table>
            <tr>
                <th>ID</th><th>Title</th><th>Company</th><th>Posted At</th>
            </tr>
            <?php while($job = $jobs->fetch_assoc()): ?>
                <tr>
                    <td><?= $job['job_id'] ?></td>
                    <td><?= htmlspecialchars($job['title']) ?></td>
                    <td><?= htmlspecialchars($job['company_name']) ?></td>
                    <td><?= $job['posted_at'] ?></td>
                </tr>
            <?php endwhile; ?>
        </table>

        <h2>📄 All Applications</h2>
        <a href="export_applications.php">Export Applications</a>
        <table>
            <tr>
                <th>ID</th><th>Employee</th><th>Job Title</th><th>Status</th><th>Date</th><th>Update</th>
            </tr>
            <?php while($app = $applications->fetch_assoc()): ?>
                <tr>
                    <td><?= $app['application_id'] ?></td>
                    <td><?= htmlspecialchars($app['employee_name']) ?></td>
                    <td><?= htmlspecialchars($app['title']) ?></td>
                    <td><?= ucfirst($app['status']) ?></td>
                    <td><?= $app['application_date'] ?></td>
                    <td>
                        <form method="POST" action="update_status.php" style="display:inline;">
                            <input type="hidden" name="application_id" value="<?= $app['application_id'] ?>">
                            <select name="status">
                                <option value="pending" <?= $app['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                <option value="accepted" <?= $app['status'] == 'accepted' ? 'selected' : '' ?>>Accepted</option>
                                <option value="rejected" <?= $app['status'] == 'rejected' ? 'selected' : '' ?>>Rejected</option>
                            </select>
                            <input type="submit" value="Update">
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </table>

        <a href="logout.php" class="btn" style="background-color:#e60023; margin-top:20px;">Logout</a>
    </div>

    <div class="footer">© 2025 MoroccoHire Admin. All rights reserved.</div>

</body>
</html>
